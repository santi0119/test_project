package com.example.websitejualan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
